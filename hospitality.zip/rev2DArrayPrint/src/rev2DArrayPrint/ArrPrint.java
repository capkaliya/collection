package rev2DArrayPrint;

import java.util.Scanner;

public class ArrPrint {

	public static void main(String[] args)  {
		
		String str="abcdefghijklmnopqrstuvwxyz";
		int k=str.length()-1,i,j,row,column;
		row = (int) Math.floor(Math.sqrt(str.length())); 
		column = (int) Math.floor(Math.sqrt(str.length())); 

		char[][] a = new char[7][column];

		for (i = 0; i < 7; i++) {
			for (j = 0; j < 4; j++) { 
				if(k >= 0) 
					a[i][j] = str.charAt(k); 
				k--; 
			} 
		}

		for (i = 0; i < a.length; i++) {

			// Loop through all elements of current row
			for (j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
				}
			System.out.println(""); 
		}
	}


}
