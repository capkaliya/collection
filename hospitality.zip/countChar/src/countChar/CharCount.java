package countChar;

import java.util.HashMap;

public class CharCount {
	public static void main(String[] args) {
		
		int count=0,i;
		String str = "Let�s take a look at Nature�s way";
		
		
		HashMap<Character, Integer> charcount = new HashMap<Character, Integer>();
			for(i = 0; i < str.length(); i++) {
				System.out.println(str.charAt(i));
				if(charcount.containsKey(str.charAt(i)))
				{
					charcount.put(str.charAt(i), count++);
				}
				else
					charcount.put(str.charAt(i), 1);
			
		}
		
		charcount.get('a');
	}
}
